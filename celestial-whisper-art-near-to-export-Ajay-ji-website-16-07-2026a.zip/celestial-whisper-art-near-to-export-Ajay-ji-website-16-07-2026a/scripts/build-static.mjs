#!/usr/bin/env node
/**
 * Static build for Hostinger shared hosting.
 * 1. Generates public/sitemap.xml
 * 2. Runs `vite build` with STATIC_BUILD=1 (nitro static preset + prerender)
 * Works on Windows, macOS, Linux.
 */
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = join(__dirname, "..");

function run(cmd, args, extraEnv = {}) {
  const res = spawnSync(cmd, args, {
    stdio: "inherit",
    cwd: ROOT,
    shell: process.platform === "win32",
    env: { ...process.env, ...extraEnv },
  });
  if (res.status !== 0) process.exit(res.status ?? 1);
}

console.log("→ Generating sitemap.xml");
run("node", ["./scripts/generate-sitemap.mjs"]);

console.log("→ Building static site (this may take a minute)");
run("npx", ["vite", "build"], { STATIC_BUILD: "1" });

console.log("\n✅ Static build complete!");
console.log("   Upload the entire contents of the `dist/` (or `.output/public/`) folder");
console.log("   to your Hostinger public_html/ directory.");
console.log("   See HOSTING_GUIDE.md for step-by-step instructions.\n");
