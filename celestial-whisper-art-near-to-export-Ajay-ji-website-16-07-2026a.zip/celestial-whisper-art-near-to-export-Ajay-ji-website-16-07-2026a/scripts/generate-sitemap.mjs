#!/usr/bin/env node
/**
 * Generates public/sitemap.xml at build time for static hosting.
 * Reads BLOG_POSTS slugs from src/lib/blog-posts.ts by regex (no TS import needed).
 */
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = join(__dirname, "..");
const BASE_URL = process.env.SITE_URL || "https://celestial-whisper-art.lovable.app";

const src = readFileSync(join(ROOT, "src/lib/blog-posts.ts"), "utf8");
const slugs = [...src.matchAll(/slug:\s*["'`]([a-z0-9-]+)["'`]/g)].map((m) => m[1]);

const staticEntries = [
  { path: "/", changefreq: "weekly", priority: "1.0" },
  { path: "/blog", changefreq: "daily", priority: "0.9" },
  { path: "/privacy", changefreq: "yearly", priority: "0.3" },
  { path: "/terms", changefreq: "yearly", priority: "0.3" },
  { path: "/refund", changefreq: "yearly", priority: "0.3" },
];

const postEntries = slugs.map((s) => ({
  path: `/blog/${s}`,
  changefreq: "monthly",
  priority: "0.7",
}));

const today = new Date().toISOString().slice(0, 10);
const entries = [...staticEntries, ...postEntries];

const xml = [
  `<?xml version="1.0" encoding="UTF-8"?>`,
  `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
  ...entries.map((e) =>
    [
      `  <url>`,
      `    <loc>${BASE_URL}${e.path}</loc>`,
      `    <lastmod>${today}</lastmod>`,
      `    <changefreq>${e.changefreq}</changefreq>`,
      `    <priority>${e.priority}</priority>`,
      `  </url>`,
    ].join("\n"),
  ),
  `</urlset>`,
].join("\n");

mkdirSync(join(ROOT, "public"), { recursive: true });
writeFileSync(join(ROOT, "public/sitemap.xml"), xml);
console.log(`✓ sitemap.xml generated (${entries.length} URLs)`);
