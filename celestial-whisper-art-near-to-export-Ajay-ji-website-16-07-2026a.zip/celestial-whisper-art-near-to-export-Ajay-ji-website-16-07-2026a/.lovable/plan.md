
# Hostinger Shared Hosting Deployment Plan

Aapki shared hosting Node.js/SSR nahi chala sakti, isliye website ko **fully static (pre-rendered HTML)** banayenge. Har page ka HTML pehle se generate hoga, aur aap `public_html` me upload karoge.

## Kya kaam karega / kya nahi

**Karega ✅** — saari pages (Home, Blog, Blog article, Privacy, Terms, Refund, 404), images, gallery, video links, WhatsApp/Call buttons, contact form (form WhatsApp pe direct message bhejta hai, backend nahi chahiye), newsletter (WhatsApp based), SEO meta tags, schema markup, sitemap, robots.txt.

**Nahi karega ❌** — kuch nahi tootega kyunki aapki site me koi server-side database ya login nahi hai. Sirf `sitemap.xml` ko static bana denge (dynamic route ki jagah build-time file).

## Changes jo main karunga

### 1. Static build configuration
- `vite.config.ts` me **prerender** enable karunga — har route (`/`, `/blog`, `/blog/<slug>`, `/privacy`, `/terms`, `/refund`) ka HTML file build hoga.
- `src/routes/sitemap[.]xml.ts` (server route) ko hata ke `public/sitemap.xml` static file bana denge — jab aap naya article add karoge, sitemap automatically rebuild pe update hoga via a small build script.

### 2. Hostinger ke liye `.htaccess`
`public/.htaccess` file add karunga jo:
- Clean URLs kaam karayegi (`/blog/my-article` → `/blog/my-article.html`)
- 404 pe custom 404 page dikhayegi
- Gzip compression + browser caching enable karegi (speed)
- HTTPS force karegi

### 3. Article add karne ka workflow (aapke liye)

**File jaha article add karna hai:** `src/lib/blog-posts.ts`

Us file ke top pe pehle se Hinglish instructions likhe hain. Flow ye rahega:

```text
1. Lovable editor me src/lib/blog-posts.ts kholo
2. BLOG_POSTS array me sabse upar naya object paste karo:
   {
     slug: "naya-article-ka-url",       // unique, chhote letters, dash
     title: "Article Ka Title",
     excerpt: "2-3 line summary...",
     date: "15 July 2026",
     tag: "Love Astrology",
     category: "Love",                   // Love | Career | Marriage | Vastu | Remedies
     author: "Ajay Shastri Ji",
     readTime: "5 min read",
     cover: "image URL ya /images/xyz.webp",
     content: `
Yaha article ka poora content likho.

## Heading aise banao

- Bullet point aise
- Doosra point
`.trim(),
   }
3. Lovable automatically build kar dega
4. Neeche bataye "Publish to Hostinger" steps follow karo
```

### 4. Hostinger pe upload karne ka process (aap manually karoge)

Main aapko `HOSTING_GUIDE.md` file bana ke dunga project root me. Us me exact steps honge:

```text
1. Lovable me "Publish" click karo (build trigger hoga)
2. Lovable se project download karo (Settings → Export / GitHub)
3. Local me: npm install && npm run build
4. build/client folder ka SAARA content copy karo
5. Hostinger hPanel → File Manager → public_html me paste karo
   (purani files pehle delete kar do)
6. Done — 1-2 minute me live
```

**Simpler alternative** (agar aap technical steps nahi karna chahte): Lovable pe hi hosted rakho, sirf Hostinger ka **domain** connect karo (DNS records). Zero maintenance, articles bas edit-and-save. Ye main strongly recommend karta hoon — but aapne shared hosting bola isliye upar wala full flow diya.

## Kaam ka order

1. `vite.config.ts` me prerender routes list add karna
2. `src/routes/sitemap[.]xml.ts` delete karna, `scripts/generate-sitemap.mjs` banana jo build ke pehle `public/sitemap.xml` likhe
3. `package.json` me `"prebuild": "node scripts/generate-sitemap.mjs"` add karna
4. `public/.htaccess` create karna (clean URLs + caching + HTTPS)
5. `public/404.html` — build ke baad Apache ke liye rename copy
6. `HOSTING_GUIDE.md` — Hindi/Hinglish me step-by-step Hostinger upload guide
7. `src/lib/blog-posts.ts` ke top ke comments update karna — Hostinger flow reflect kare

## Ek zaroori confirm

Agar main static build karta hoon, contact form ka data **kahaan jaayega** — abhi WhatsApp pe hi jata hai (form fill → WhatsApp message open). Ye shared hosting pe bhi waise hi kaam karega. Kya ye theek hai, ya aap chahte ho form email pe aaye? (Email ke liye chahiye toh ek 3rd-party service like Formspree/Web3Forms use karni padegi — free plan available hai.)

Confirm karo toh implement karna shuru karun.
